package Plugins::Caprice::Settings;

# Plugin to stream audio from Radio Caprice channels
#
# Released under the MIT Licence
# Written by Daniel Vijge
# See file LICENSE for full licence details

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Strings qw(string);
use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $log   = logger('plugin.caprice');
my $prefs = preferences('plugin.caprice');
$prefs->init({ menuLocation => 'radio', orderBy => 'popular', groupByGenre => 0, streamingQuality => 'highest:aac', descriptionInTitle => 0, secondLineText => 'description' });

# Returns the name of the plugin. The real 
# string is specified in the strings.txt file.
sub name {
    return 'PLUGIN_CAPRICE';
}

sub page {
    return 'plugins/Caprice/settings/basic.html';
}

sub prefs {
    return (preferences('plugin.caprice'), qw(menuLocation orderBy groupByGenre streamingQuality descriptionInTitle secondLineText));
}

# Always end with a 1 to make Perl happy
1;
